from random import choice, randrange
from .draw_maze import DrawMaze
from .types import Coord

PATTERN_42 = [
    (0, 0),
    (1, 0),
    (2, 0), (2, 1), (2, 2),
    (3, 2),
    (4, 2),
    # digit "2"
    (0, 4), (0, 5), (0, 6),
    (1, 6),
    (2, 4), (2, 5), (2, 6),
    (3, 4),
    (4, 4), (4, 5), (4, 6),
]


class Maze:
    """Generate and serialize mazes from a config file."""

    hex_file = "hex_maze"

    def __init__(self, config_path: str) -> None:
        """Initialize maze defaults, load config data, and validate"""
        self.env = config_path
        self.width: int = 3
        self.height: int = 3
        self.entry: Coord
        self.exit: Coord
        self.seed: int | None = None
        self.output_file: str
        self.perfect: bool
        self.pattern_42_cells: set[Coord] = set()
        self.grid: list[list[dict[str, bool]]] = []
        self.drawer = DrawMaze(self)
        self._load_env_data()
        self._validate_entry_exit()

    @staticmethod
    def _parse_coord(value: str) -> Coord:
        """Parse an ``x,y`` coordinate string.

        Return the coordinate as internal ``(y, x)``.
        """
        parts = value.split(",")
        if len(parts) != 2:
            raise ValueError("coordinates must be in 'x,y' format")
        x = int(parts[0].strip())
        y = int(parts[1].strip())
        return (y, x)

    @staticmethod
    def _parse_bool(value: str) -> bool:
        """Parse common boolean string representations."""
        normalized = value.strip().lower()
        if normalized in {"true", "1", "yes", "y", "on"}:
            return True
        if normalized in {"false", "0", "no", "n", "off"}:
            return False
        raise ValueError("invalid boolean value")

    def _load_env_data(self) -> None:
        """Load and validate config values from a KEY=VALUE file."""
        required_keys = {
            "WIDTH", "HEIGHT", "ENTRY", "EXIT", "OUTPUT_FILE", "PERFECT"
        }
        parsed_keys: set[str] = set()
        try:
            with open(self.env, "r") as f:
                for line_number, raw_line in enumerate(f, start=1):
                    line = raw_line.strip()
                    if not line or line.startswith("#"):
                        continue
                    if "#" in line:
                        line = line.split("#", 1)[0].strip()
                        if not line:
                            continue
                    if "=" not in line:
                        raise ValueError(
                            f"line {line_number}: expected KEY=VALUE")

                    key_raw, value_raw = line.split("=", 1)
                    key = key_raw.strip().upper()
                    value = value_raw.strip()

                    if not key:
                        raise ValueError(f"line {line_number}: empty key")
                    if not value:
                        raise ValueError(
                            f"line {line_number}: empty value for {key}")

                    if key == "WIDTH":
                        self.width = int(value)
                        if self.width <= 0:
                            raise ValueError("WIDTH must be > 0")
                        parsed_keys.add(key)
                    elif key == "HEIGHT":
                        self.height = int(value)
                        if self.height <= 0:
                            raise ValueError("HEIGHT must be > 0")
                        parsed_keys.add(key)
                    elif key == "ENTRY":
                        self.entry = self._parse_coord(value)
                        parsed_keys.add(key)
                    elif key == "EXIT":
                        self.exit = self._parse_coord(value)
                        parsed_keys.add(key)
                    elif key == "PERFECT":
                        self.perfect = self._parse_bool(value)
                        parsed_keys.add(key)
                    elif key == "OUTPUT_FILE":
                        self.output_file = value
                        parsed_keys.add(key)
                    elif key == "SEED":
                        self.seed = int(value)

            missing = sorted(required_keys - parsed_keys)
            if missing:
                raise ValueError(
                    f"missing required keys: {', '.join(missing)}")
        except FileNotFoundError:
            print("ERROR: file not found")
            exit(1)
        except PermissionError:
            print("ERROR: file permissions")
            exit(1)
        except ValueError as e:
            print(f"ERROR: invalid config - {e}")
            exit(1)
        except Exception as e:
            print(f"Unknown ERROR: {e}")
            exit(1)

    def _validate_entry_exit(self) -> None:
        """
        Validate that entry and exit points are within bounds and not equal
        """
        try:
            if not (0 <= self.entry[0] < self.height and
                    0 <= self.entry[1] < self.width):
                raise ValueError("Entry point out of bounds")
            if not (0 <= self.exit[0] < self.height and
                    0 <= self.exit[1] < self.width):
                raise ValueError("Exit point out of bounds")
            if self.entry == self.exit:
                raise ValueError("Entry must != Exit")
        except ValueError as e:
            print(f"ERROR: Invalid entry/exit coordinates - {e}")
            exit(1)

    def _cell_to_hex(self, cell: Coord) -> str:
        """Convert one cell wall state to a single hexadecimal character."""
        y, x = cell
        val = 0
        cel = self.grid[y][x]
        if cel["N"]:
            val += 1
        if cel["E"]:
            val += 2
        if cel["S"]:
            val += 4
        if cel["W"]:
            val += 8
        return hex(val)[2:].upper()

    def save_to_file(self) -> None:
        """Write the current maze grid to the configured output file."""
        try:
            with open(self.output_file, "w") as f:
                for y in range(self.height):
                    for x in range(self.width):
                        f.write(self._cell_to_hex((y, x)))
                    f.write("\n")
                f.write("\n")
                f.write(f"{self.entry[1]},{self.entry[0]}\n")
                f.write(f"{self.exit[1]},{self.exit[0]}\n")
                bfs_path = self.solve_bfs()
                ll = self.path_to_directions(bfs_path)
                f.write(f"{ll}\n")
        except Exception:
            print("save_to_file(): ERROR")
            exit(1)

    def build_grid(self) -> None:
        """ Build grid using width and height """
        for _ in range(self.height):
            lis: list[dict[str, bool]] = []
            for _ in range(self.width):
                cell = {
                        "visited": False,
                        "N": True,
                        "E": True,
                        "S": True,
                        "W": True
                    }
                lis.append(cell)
            self.grid.append(lis)

    def get_neighbors_cells(self, cell: Coord) -> list[Coord]:
        """ Get only neigbors of an cell that are not visited
            return:
                    list of cords (of neigbors)
        """
        neigbors: list[Coord] = []
        y, x = cell
        # check north
        if y - 1 >= 0 and self.grid[y - 1][x]["visited"] is False:
            neigbors.append((y - 1, x))
        # check east
        if x + 1 < self.width and self.grid[y][x + 1]["visited"] is False:
            neigbors.append((y, x + 1))
        # check south
        if y + 1 < self.height and self.grid[y + 1][x]["visited"] is False:
            neigbors.append((y + 1, x))
        # check west
        if x - 1 >= 0 and self.grid[y][x - 1]["visited"] is False:
            neigbors.append((y, x - 1))
        return neigbors

    def remove_walls(self, cell1: Coord, cell2: Coord) -> None:
        """ Remove walls bettwen two cells """
        y1, x1 = cell1
        y2, x2 = cell2
        # check North
        if y1 - 1 == y2 and x1 == x2:
            self.grid[y1][x1]["N"] = False
            self.grid[y2][x2]["S"] = False
        # check East
        elif y1 == y2 and x1 + 1 == x2:
            self.grid[y1][x1]["E"] = False
            self.grid[y2][x2]["W"] = False
        # check South
        elif y1 + 1 == y2 and x1 == x2:
            self.grid[y1][x1]["S"] = False
            self.grid[y2][x2]["N"] = False
        # check West
        elif y1 == y2 and x1 - 1 == x2:
            self.grid[y1][x1]["W"] = False
            self.grid[y2][x2]["E"] = False
        else:
            print("Error: Cells dosent much")

    def _place_42_pattern(self) -> None:
        """Reserve a centered 42 pattern using fully closed cells."""
        self.pattern_42_cells.clear()
        if self.width < 9 or self.height < 7:
            print("WARNING: maze too small to draw 42 pattern")
            return

        start_row = (self.height - 5) // 2
        start_col = (self.width - 7) // 2

        for (dr, dc) in PATTERN_42:
            y = start_row + dr
            x = start_col + dc
            self.pattern_42_cells.add((y, x))
            self.grid[y][x]["visited"] = True

    def solve_bfs(self) -> list[Coord]:
        """Return a shortest valid path from entry to exit using BFS."""

        from collections import deque

        start = self.entry
        end = self.exit

        visited: dict[Coord, Coord | None] = {start: None}
        queue: deque[Coord] = deque([start])

        while queue:
            y, x = queue.popleft()

            if (y, x) == end:
                path = []
                current: Coord | None = end
                while current is not None:
                    path.append(current)
                    current = visited[current]

                path.reverse()
                return path

            if y - 1 >= 0 and not self.grid[y][x]["N"]:
                neighbor: Coord = (y - 1, x)
                if neighbor not in visited:
                    visited[neighbor] = (y, x)  # came FROM (y,x)
                    queue.append(neighbor)

            if x + 1 < self.width and not self.grid[y][x]["E"]:
                neighbor = (y, x + 1)
                if neighbor not in visited:
                    visited[neighbor] = (y, x)
                    queue.append(neighbor)

            if y + 1 < self.height and not self.grid[y][x]["S"]:
                neighbor = (y + 1, x)
                if neighbor not in visited:
                    visited[neighbor] = (y, x)
                    queue.append(neighbor)

            if x - 1 >= 0 and not self.grid[y][x]["W"]:
                neighbor = (y, x - 1)
                if neighbor not in visited:
                    visited[neighbor] = (y, x)
                    queue.append(neighbor)

        return []

    def path_to_directions(self, path: list[Coord]) -> str:
        """Convert a path of cells into N/E/S/W movement letters."""
        directions: list[str] = []
        for i in range(len(path) - 1):
            y1, x1 = path[i]
            y2, x2 = path[i + 1]

            if y2 < y1:
                directions.append("N")
            elif x2 > x1:
                directions.append("E")
            elif y2 > y1:
                directions.append("S")
            elif x2 < x1:
                directions.append("W")
        return "".join(directions)

    def _build_maze_dfs(self) -> None:
        """Generate the maze using iterative DFS with backtracking."""
        start = self.entry
        stack: list[Coord] = [start]
        y, x = start
        self.grid[y][x]["visited"] = True

        self._place_42_pattern()

        while stack:
            neighbors = self.get_neighbors_cells(stack[-1])
            if neighbors:
                y1, x1 = neighbor = choice(neighbors)
                self.remove_walls(stack[-1], neighbor)
                self.grid[y1][x1]["visited"] = True
                stack.append(neighbor)
            else:
                stack.pop()

    def _add_extra_openings(self) -> None:
        """Open extra walls to create loops for non-perfect mazes."""
        extra_openings = max(1, (self.width * self.height) // 20)
        opened = 0

        while opened < extra_openings:
            y = randrange(self.height)
            x = randrange(self.width)

            if (y, x) in self.pattern_42_cells:
                continue

            # Try to open north
            if (self.grid[y][x]["N"] and y - 1 >= 0 and
                    (y - 1, x) not in self.pattern_42_cells):
                self.remove_walls((y, x), (y - 1, x))
                opened += 1
            # Try to open east
            elif (self.grid[y][x]["E"] and x + 1 < self.width and
                    (y, x + 1) not in self.pattern_42_cells):
                self.remove_walls((y, x), (y, x + 1))
                opened += 1
            # Try to open south
            elif (self.grid[y][x]["S"] and y + 1 < self.height and
                    (y + 1, x) not in self.pattern_42_cells):
                self.remove_walls((y, x), (y + 1, x))
                opened += 1
            # Try to open west
            elif (self.grid[y][x]["W"] and x - 1 >= 0 and
                    (y, x - 1) not in self.pattern_42_cells):
                self.remove_walls((y, x), (y, x - 1))
                opened += 1

    def build_maze(self) -> None:
        """
        Build the maze according to PERFECT flag.

        PERFECT=True  -> DFS tree only (unique path between entry and exit).
        PERFECT=False -> DFS tree + extra openings (adds loops).
        """
        self._build_maze_dfs()
        if not self.perfect:
            self._add_extra_openings()
